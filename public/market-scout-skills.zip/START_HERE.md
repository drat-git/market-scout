# Market Scout skills

This bundle contains four skills and their operating guide. It requires the
[Market Scout repository](https://github.com/drat-git/market-scout), Node 22+, and npm dependencies; it is not a standalone
application and does not contain the CLI. Example configurations and research
inputs are included; the commercial-HVAC input is clearly labeled fictional.

Start with [installation and commands](docs/CLI.md), then the
[offline walkthrough](docs/WALKTHROUGH.md) or [research SOP](docs/SOP.md).
Copy complete skill folders, including references and agents metadata, into the
project-scoped skills directory described in the installation guide.

The default CLI makes no AI API calls. Your assistant collects sources and writes
analysis using its available tools. Configure your industry, markets, criteria,
and comparison groups with docs/CASE-CONFIG.md. Austin/San Antonio pediatric
therapy is one example configuration. The public dashboard stays separate.

Generated from the repository's canonical skills by npm run package:skills.
Source-code links in the guides resolve in the required repository checkout.
